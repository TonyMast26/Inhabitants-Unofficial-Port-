package com.jeremyseq.inhabitants;

import com.jeremyseq.inhabitants.util.StackData;
import com.jeremyseq.inhabitants.blocks.entity.ModBlockEntities;
import com.jeremyseq.inhabitants.compat.ModBiomeModifiers;
import com.jeremyseq.inhabitants.effects.ModEffects;
import com.jeremyseq.inhabitants.debug.DebugCommands;
import com.jeremyseq.inhabitants.blocks.ModBlocks;
import com.jeremyseq.inhabitants.entities.ModEntities;
import com.jeremyseq.inhabitants.entities.impaler.arrow.ConcussionArrowDispenserBehavior;
import com.jeremyseq.inhabitants.entities.impaler.arrow.ConcussionArrowRenderer;
import com.jeremyseq.inhabitants.items.*;
import com.jeremyseq.inhabitants.loot_modifiers.ModLootModifiers;
import com.jeremyseq.inhabitants.networking.ModNetworking;
import com.jeremyseq.inhabitants.particles.ModParticles;
import com.jeremyseq.inhabitants.potions.ModPotions;
import com.jeremyseq.inhabitants.recipe.BogreRecipeManager;
import com.jeremyseq.inhabitants.gui.cauldron.CauldronScreen;
import com.jeremyseq.inhabitants.audio.ModSoundEvents;
import com.jeremyseq.inhabitants.items.SpikeDrillItem;
import com.jeremyseq.inhabitants.animation.FPVAnimationManager;
import com.jeremyseq.inhabitants.gui.*;
import com.jeremyseq.inhabitants.entities.bogre.render.BogreRenderer;
import com.jeremyseq.inhabitants.entities.bogre.bogre_cauldron.BogreCauldronRenderer;
import com.jeremyseq.inhabitants.entities.impaler.ImpalerRenderer;
import com.jeremyseq.inhabitants.entities.impaler.spike.ImpalerSpikeRenderer;
import com.jeremyseq.inhabitants.entities.warped_clam.WarpedClamRenderer;
import com.jeremyseq.inhabitants.entities.javelin.JavelinRenderer;
import com.jeremyseq.inhabitants.blocks.impaler_head.ImpalerHeadRenderer;

import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.client.resources.model.ModelResourceLocation;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.AddReloadListenerEvent;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.*;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.client.event.*;
import net.neoforged.fml.common.EventBusSubscriber;
import com.jeremyseq.inhabitants.blocks.ModCapabilities;

import org.slf4j.Logger;

import com.mojang.logging.LogUtils;

@Mod(Inhabitants.MODID)
public class Inhabitants
{
    public static final String MODID = "inhabitants";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Inhabitants(IEventBus modEventBus)
    {
        ModCreativeModeTabs.register(modEventBus);

        ModItems.register(modEventBus);
        ModEffects.register(modEventBus);
        ModPotions.register(modEventBus);

        modEventBus.addListener(this::commonSetup);

        ModBlocks.register(modEventBus);
        ModEntities.REGISTRY.register(modEventBus);
        ModBlockEntities.register(modEventBus);
        ModMenuTypes.MENU_TYPES.register(modEventBus);
        ModParticles.PARTICLES.register(modEventBus);
        ModLootModifiers.register(modEventBus);
        ModSoundEvents.register(modEventBus);
        modEventBus.addListener(ModNetworking::register);
        modEventBus.addListener(ModCapabilities::register);
        ModBiomeModifiers.register(modEventBus);

        NeoForge.EVENT_BUS.register(this);
        NeoForge.EVENT_BUS.register(DebugCommands.class);

        modEventBus.addListener(this::addCreative);
        NeoForge.EVENT_BUS.addListener(ModPotions::registerBrewingRecipes);
    }

    private void commonSetup(final FMLCommonSetupEvent event)
    {
        event.enqueueWork(() -> {
            DispenserBlock.registerBehavior(ModItems.CONCUSSION_ARROW.get(),
            new ConcussionArrowDispenserBehavior());
        });
    }

    private void addCreative(BuildCreativeModeTabContentsEvent event)
    {

    }

    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event)
    {

    }

    @SubscribeEvent
    public void onAddReloadListeners(AddReloadListenerEvent event)
    {
        event.addListener(new BogreRecipeManager());
    }

    @EventBusSubscriber(modid = MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents
    {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event)
        {
            ItemProperties.register(ModItems.WARPED_CLAM_ITEM.get(),
                    ResourceLocation.fromNamespaceAndPath(MODID, "variant"), (stack, level, entity, seed) -> {
                        return (float) StackData.get(stack).getInt("variant");
                    });

            ItemProperties.register(ModItems.JAVELIN.get(),
                ResourceLocation.fromNamespaceAndPath(MODID, "aiming"), (stack, level, entity, seed) -> {
                    return entity != null &&
                    entity.isUsingItem() &&
                    entity.getUseItem() == stack ? 1.0F : 0.0F;
                });

            ItemProperties.register(ModItems.SPIKE_DRILL.get(),
                ResourceLocation.fromNamespaceAndPath(MODID, "drilling"), (stack, level, entity, seed) -> {
                    return entity != null &&
                    entity.isUsingItem() &&
                    entity.getUseItem() == stack ? 1.0F : 0.0F;
                });

            ItemProperties.register(ModItems.SPIKE_DRILL.get(),
                ResourceLocation.fromNamespaceAndPath(MODID, "drill_temperature"), (stack, level, entity, seed) -> {
                    int temperature = SpikeDrillItem.getTemperature(stack);
                    float ratio = (float) temperature / SpikeDrillItem.getTemperatureMax(stack);
                    
                    if (ratio >= 1.0F)  return 1.0F;
                    if (ratio >= 0.75F) return 0.75F;
                    if (ratio >= 0.50F) return 0.50F;
                    if (ratio >= 0.25F) return 0.25F;
                    return 0.0F;
                });
        }

        @SubscribeEvent
        public static void onRegisterAdditional(ModelEvent.RegisterAdditional event) {
            event.register(ModelResourceLocation.standalone(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "item/javelin_gui")));
        }

        @SubscribeEvent
        public static void onRegisterReloadListeners(RegisterClientReloadListenersEvent event) {
            event.registerReloadListener(FPVAnimationManager.INSTANCE);
        }

        @SubscribeEvent
        public static void onRegisterGuiLayers(RegisterGuiLayersEvent event) {
            event.registerAboveAll(ResourceLocation.fromNamespaceAndPath(MODID, "drill_heat"), DrillHeatOverlay.HUD_DRILL_HEAT);
        }

        @SubscribeEvent
        public static void onRegisterMenuScreens(RegisterMenuScreensEvent event) {
            event.register(ModMenuTypes.CAULDRON_MENU.get(), CauldronScreen::new);
        }

        @SubscribeEvent
        public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
            event.registerEntityRenderer(ModEntities.BOGRE.get(), BogreRenderer::new);
            event.registerEntityRenderer(ModEntities.BOGRE_CAULDRON.get(), BogreCauldronRenderer::new);
            event.registerEntityRenderer(ModEntities.WARPED_CLAM.get(), WarpedClamRenderer::new);
            event.registerEntityRenderer(ModEntities.IMPALER.get(), ImpalerRenderer::new);
            event.registerEntityRenderer(ModEntities.IMPALER_SPIKE_PROJECTILE.get(), ImpalerSpikeRenderer::new);
            event.registerEntityRenderer(ModEntities.JAVELIN.get(), JavelinRenderer::new);
            event.registerEntityRenderer(ModEntities.CONCUSSION_ARROW_PROJECTILE.get(), ConcussionArrowRenderer::new);

            event.registerBlockEntityRenderer(ModBlockEntities.IMPALER_HEAD_BLOCK_ENTITY.get(),
                    context -> new ImpalerHeadRenderer());
        }
    }

    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event)
    {
        if (event.getEntity() instanceof ServerPlayer serverPlayer) {
            BogreRecipeManager.sendBogreRecipesToPlayer(serverPlayer);
        }
    }
}
