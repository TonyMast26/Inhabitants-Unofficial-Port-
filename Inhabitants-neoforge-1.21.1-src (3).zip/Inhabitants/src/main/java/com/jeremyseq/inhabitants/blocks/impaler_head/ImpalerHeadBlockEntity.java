package com.jeremyseq.inhabitants.blocks.impaler_head;

import net.minecraft.core.HolderLookup;

import com.jeremyseq.inhabitants.blocks.entity.ModBlockEntities;

import com.jeremyseq.inhabitants.entities.impaler.ImpalerEntity;
import net.minecraft.core.*;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.properties.RotationSegment;

import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import org.jetbrains.annotations.*;

import java.util.List;

public class ImpalerHeadBlockEntity extends BlockEntity implements GeoBlockEntity {
    private ImpalerEntity.Variant variant;
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int attackTimer = -1;
    private ResourceLocation noteBlockSound = ResourceLocation
        .fromNamespaceAndPath("inhabitants", "impaler.idle");

    public ImpalerHeadBlockEntity(BlockPos pPos, BlockState pBlockState) {
        super(ModBlockEntities.IMPALER_HEAD_BLOCK_ENTITY.get(), pPos, pBlockState);
    }

    public ImpalerHeadBlockEntity(BlockPos pPos, BlockState pBlockState, ImpalerEntity.Variant variant) {
        super(ModBlockEntities.IMPALER_HEAD_BLOCK_ENTITY.get(), pPos, pBlockState);
        this.setVariant(variant);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "attack_controller", 0, state -> {
            if (state.getAnimatable().getBlockState().getValue(AbstractImpalerHeadBlock.POWERED)) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("attack"));
            }
            return PlayState.STOP;
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    protected void saveAdditional(@NotNull CompoundTag pTag, @NotNull HolderLookup.Provider pRegistries) {
        super.saveAdditional(pTag, pRegistries);
        if (this.noteBlockSound != null) {
            pTag.putString("note_block_sound", this.noteBlockSound.toString());
        }
        if (variant != null) {
            pTag.putInt("variant", this.getVariant().getId());
        }
    }

    @Override
    protected void loadAdditional(@NotNull CompoundTag pTag, @NotNull HolderLookup.Provider pRegistries) {
        super.loadAdditional(pTag, pRegistries);
        if (pTag.contains("note_block_sound", 8)) {
            this.noteBlockSound = ResourceLocation
                .tryParse(pTag.getString("note_block_sound"));
        }

        if (pTag.contains("variant")) {
            this.setVariant(ImpalerEntity.Variant.values()[pTag.getInt("variant")]);
        }
    }

    public ImpalerEntity.Variant getVariant() {
        return variant;
    }

    public void setVariant(ImpalerEntity.Variant v) {
        variant = v;
    }

    @Nullable
    public ResourceLocation getNoteBlockSound() {
        return this.noteBlockSound;
    }

    public void setNoteBlockSound(@Nullable ResourceLocation pNoteBlockSound) {
        this.noteBlockSound = pNoteBlockSound;
    }

    @Override
    public @NotNull CompoundTag getUpdateTag(@NotNull HolderLookup.Provider pRegistries) {
        return super.getUpdateTag(pRegistries);
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    public static void tick(
        Level level,
        BlockPos pos,
        BlockState state,
        ImpalerHeadBlockEntity blockEntity
    ) {
        if (state.getValue(AbstractImpalerHeadBlock.POWERED)) {
            blockEntity.attackTimer++;

            if (blockEntity.attackTimer >= 13) {
                blockEntity.attackTimer = 0;
            }

            if (blockEntity.attackTimer == 5) {
                blockEntity.performAttack();
            }
        } else {
            blockEntity.attackTimer = -1;
        }
    }

    private void performAttack() {
        if (this.level == null || this.level.isClientSide) return;

        BlockPos pos = this.getBlockPos();
        BlockState state = this.level.getBlockState(pos);
        Direction facing;
        
        if (state.hasProperty(ImpalerWallHeadBlock.FACING)) {
            facing = state.getValue(ImpalerWallHeadBlock.FACING).getOpposite();
        } else if (state.hasProperty(ImpalerHeadBlock.ROTATION)) {
            int rotation = state.getValue(ImpalerHeadBlock.ROTATION);
            facing = Direction.fromYRot(RotationSegment.convertToDegrees(rotation)).getOpposite();
        } else {
            return;
        }

        BlockPos targetPos = pos.relative(facing);
        AABB area = new AABB(targetPos).inflate(0.25D);
        
        List<LivingEntity> entities = this.level.getEntitiesOfClass(LivingEntity.class, area);

        for (LivingEntity entity : entities) {
            entity.hurt(this.level.damageSources().magic(), 1.0F);
        }
    }
}
