package com.jeremyseq.inhabitants.networking.bogre;

import com.jeremyseq.inhabitants.recipe.CookingRecipe;
import com.jeremyseq.inhabitants.recipe.BogreRecipeManager;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import com.jeremyseq.inhabitants.Inhabitants;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.minecraft.core.registries.BuiltInRegistries;

import java.util.*;

public class BogreRecipePacketS2C implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<BogreRecipePacketS2C> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "bogre_recipe_packet_s2c"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BogreRecipePacketS2C> STREAM_CODEC =
            CustomPacketPayload.codec(BogreRecipePacketS2C::encode, BogreRecipePacketS2C::decode);

    @Override
    public CustomPacketPayload.Type<BogreRecipePacketS2C> type() {
        return TYPE;
    }


    private final List<CookingRecipe> recipes;

    public BogreRecipePacketS2C(List<CookingRecipe> recipes) {
        this.recipes = recipes;
    }
    
    public static void encode(BogreRecipePacketS2C packet, RegistryFriendlyByteBuf buf) {
        buf.writeInt(packet.recipes.size());
        for (CookingRecipe recipe : packet.recipes) {
            buf.writeInt(recipe.ingredients().size());
            for (int i = 0; i < recipe.ingredients().size(); i++) {
                Item item = recipe.ingredients().get(i);
                buf.writeUtf(BuiltInRegistries.ITEM.getKey(item).toString());
                
                boolean hasTag = recipe.hasTagIngredient(i);
                buf.writeBoolean(hasTag);
                if (hasTag) {
                    buf.writeUtf(recipe.getTagForSlot(i).location().toString());
                }
            }
            
            buf.writeUtf(BuiltInRegistries.ITEM.getKey(recipe.container()).toString());
            ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, recipe.result());
            buf.writeInt(recipe.time_ticks());
        }
    }
    
    public static BogreRecipePacketS2C decode(RegistryFriendlyByteBuf buf) {
        int count = buf.readInt();
        List<CookingRecipe> recipes = new ArrayList<>();

        for (int r = 0; r < count; r++) {
            int ingCount = buf.readInt();
            List<Item> ingredients = new ArrayList<>();
            List<TagKey<Item>> tagIngredients = new ArrayList<>();
            for (int i = 0; i < ingCount; i++) {
                Item item = BuiltInRegistries.ITEM.get(ResourceLocation.tryParse(buf.readUtf()));
                ingredients.add(item != null ? item : Items.AIR);

                boolean hasTag = buf.readBoolean();
                if (hasTag) {
                    tagIngredients.add(TagKey.create(Registries.ITEM, ResourceLocation.tryParse(buf.readUtf())));
                } else {
                    tagIngredients.add(null);
                }
            }
            
            Item container = BuiltInRegistries.ITEM.get(ResourceLocation.tryParse(buf.readUtf()));
            ItemStack result = ItemStack.OPTIONAL_STREAM_CODEC.decode(buf);
            int timeTicks = buf.readInt();

            recipes.add(new CookingRecipe(
                ingredients, 
                tagIngredients, 
                container != null ? container : Items.BOWL, 
                result, 
                timeTicks));
        }

        return new BogreRecipePacketS2C(recipes);
    }
    
    public static void handle(BogreRecipePacketS2C packet, IPayloadContext ctx) {
        
        ctx.enqueueWork(() -> {
            BogreRecipeManager.setClientCookingRecipes(packet.recipes);
        });
    }
}