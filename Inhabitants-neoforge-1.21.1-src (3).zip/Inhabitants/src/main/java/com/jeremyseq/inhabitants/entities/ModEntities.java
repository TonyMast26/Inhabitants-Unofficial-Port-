package com.jeremyseq.inhabitants.entities;

import com.jeremyseq.inhabitants.Inhabitants;
import com.jeremyseq.inhabitants.entities.bogre.BogreEntity;
import com.jeremyseq.inhabitants.entities.bogre.bogre_cauldron.BogreCauldronEntity;
import com.jeremyseq.inhabitants.entities.impaler.spike.ImpalerSpikeProjectile;
import com.jeremyseq.inhabitants.entities.impaler.ImpalerEntity;
import com.jeremyseq.inhabitants.entities.impaler.arrow.ConcussionArrowProjectile;
import com.jeremyseq.inhabitants.entities.warped_clam.WarpedClamEntity;
import com.jeremyseq.inhabitants.entities.javelin.JavelinEntity;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.core.registries.BuiltInRegistries;
import net.neoforged.neoforge.registries.DeferredHolder;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ModEntities {
    public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(net.minecraft.core.registries.Registries.ENTITY_TYPE, Inhabitants.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<BogreEntity>> BOGRE =
            REGISTRY.register("bogre",
                    () -> EntityType.Builder.of(BogreEntity::new, MobCategory.MONSTER)
                            .sized(1.75f, 3.5f)
                            .build(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "bogre").toString()));

    public static final DeferredHolder<EntityType<?>, EntityType<BogreCauldronEntity>> BOGRE_CAULDRON =
            REGISTRY.register("bogre_cauldron",
                    () -> EntityType.Builder.of(BogreCauldronEntity::new, MobCategory.MISC)
                            .sized(2f, 1.3f)
                            .build(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "bogre_cauldron").toString()));

    public static final DeferredHolder<EntityType<?>, EntityType<WarpedClamEntity>> WARPED_CLAM =
            REGISTRY.register("warped_clam",
                    () -> EntityType.Builder.of(WarpedClamEntity::new, MobCategory.CREATURE)
                            .sized(1.5f, .4f)
                            .build(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "warped_clam").toString()));

    public static final DeferredHolder<EntityType<?>, EntityType<ImpalerEntity>> IMPALER =
            REGISTRY.register("impaler",
                    () -> EntityType.Builder.of(ImpalerEntity::new, MobCategory.MONSTER)
                            .sized(1, 2.4f)
                            .build(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "impaler").toString()));

    public static final DeferredHolder<EntityType<?>, EntityType<ImpalerSpikeProjectile>> IMPALER_SPIKE_PROJECTILE =
            REGISTRY.register("impaler_spike",
                    () -> EntityType.Builder.<ImpalerSpikeProjectile>of(
                                    ImpalerSpikeProjectile::new, MobCategory.MISC)
                            .sized(0.5f, 0.5f)
                            .clientTrackingRange(4)
                            .updateInterval(20)
                            .build(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "impaler_spike").toString()));

    public static final DeferredHolder<EntityType<?>, EntityType<JavelinEntity>> JAVELIN =
            REGISTRY.register("javelin",
                    () -> EntityType.Builder.<JavelinEntity>of(JavelinEntity::new, MobCategory.MISC)
                            .sized(0.75f, 0.75f)
                            .clientTrackingRange(4)
                            .updateInterval(20)
                            .build(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "javelin").toString()));

    public static final DeferredHolder<EntityType<?>, EntityType<ConcussionArrowProjectile>> CONCUSSION_ARROW_PROJECTILE =
            REGISTRY.register("concussion_arrow",
                    () -> EntityType.Builder.<ConcussionArrowProjectile>of(
                                    ConcussionArrowProjectile::new, MobCategory.MISC)
                            .sized(0.5f, 0.5f)
                            .clientTrackingRange(4)
                            .updateInterval(20)
                            .build(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "concussion_arrow").toString()));

    @SubscribeEvent
    public static void entityAttributeEvent(EntityAttributeCreationEvent event) {
        event.put(ModEntities.BOGRE.get(), BogreEntity.setAttributes());
        event.put(ModEntities.WARPED_CLAM.get(), WarpedClamEntity.setAttributes());
        event.put(ModEntities.IMPALER.get(), ImpalerEntity.setAttributes());
    }
}
