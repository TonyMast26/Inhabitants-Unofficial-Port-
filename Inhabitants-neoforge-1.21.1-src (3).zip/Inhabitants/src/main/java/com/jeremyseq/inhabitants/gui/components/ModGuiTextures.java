package com.jeremyseq.inhabitants.gui.components;

import com.jeremyseq.inhabitants.Inhabitants;
import net.minecraft.resources.ResourceLocation;

public class ModGuiTextures {

    public static class SpriteRegion {
        public final ResourceLocation texture;
        public final int u, v;
        public final int width, height;
        public final int texWidth, texHeight;

        public SpriteRegion(ResourceLocation texture, int u, int v, int width, int height, int texWidth, int texHeight) {
            this.texture = texture;
            this.u = u;
            this.v = v;
            this.width = width;
            this.height = height;
            this.texWidth = texWidth;
            this.texHeight = texHeight;
        }
    }

    // --- Cauldron Screen ---
    public static final ResourceLocation CAULDRON_GUI = register("bogre_cauldron", "cauldron_gui");
    public static final ResourceLocation SLOT = register("bogre_cauldron", "slot");
    public static final ResourceLocation GHOST_SLOT = register("bogre_cauldron", "ghost_slot");
    public static final ResourceLocation BOWL_SLOT = register("bogre_cauldron", "bowl_slot");
    
    public static final ResourceLocation FIRE_SOURCE_ON = register("bogre_cauldron", "fire_source_on");
    public static final ResourceLocation FIRE_SOURCE_OFF = register("bogre_cauldron", "fire_source_off");
    public static final ResourceLocation ARROW = register("bogre_cauldron", "arrow");
    
    public static final ResourceLocation TIP_BUTTON = register("bogre_cauldron", "tip_button");
    public static final ResourceLocation TIP_BUTTON_HIGHLIGHT = register("bogre_cauldron", "tip_button_highlight");
    public static final ResourceLocation TIP_BUTTON_PRESSED = register("bogre_cauldron", "tip_button_pressed");
    
    public static final ResourceLocation[] BUBBLES = new ResourceLocation[] {
        register("bogre_cauldron", "bubbles_1"), register("bogre_cauldron", "bubbles_2"),
        register("bogre_cauldron", "bubbles_3"), register("bogre_cauldron", "bubbles_4"),
        register("bogre_cauldron", "bubbles_5"), register("bogre_cauldron", "bubbles_6"),
        register("bogre_cauldron", "bubbles_7"), register("bogre_cauldron", "bubbles_full")
    };
    
    // --- Cauldron Recipe Book ---
    public static final ResourceLocation RECIPE_BOOK_TEX = ResourceLocation.fromNamespaceAndPath("minecraft", "textures/gui/recipe_book.png");
    
    public static final SpriteRegion RECIPE_BOOK_WIDGET = new SpriteRegion(RECIPE_BOOK_TEX, 1, 1, 147, 166, 256, 256);
    public static final ResourceLocation TEXT_FIELD = register("bogre_cauldron/recipe_book", "text_field");
    public static final ResourceLocation TEXT_FIELD_HIGHLIGHTED = register("bogre_cauldron/recipe_book", "text_field_highlighted");
    
    public static final SpriteRegion SLOT_CRAFTABLE = vanillaSprite("slot_craftable", 25, 25);
    public static final SpriteRegion SLOT_UNCRAFTABLE = vanillaSprite("slot_uncraftable", 25, 25);
    
    public static final SpriteRegion FILTER_DISABLED = vanillaSprite("filter_disabled", 26, 16);
    public static final SpriteRegion FILTER_DISABLED_HIGHLIGHTED = vanillaSprite("filter_disabled_highlighted", 26, 16);
    public static final SpriteRegion FILTER_ENABLED = vanillaSprite("filter_enabled", 26, 16);
    public static final SpriteRegion FILTER_ENABLED_HIGHLIGHTED = vanillaSprite("filter_enabled_highlighted", 26, 16);
    
    public static final SpriteRegion PAGE_FORWARD = vanillaSprite("page_forward", 12, 17);
    public static final SpriteRegion PAGE_FORWARD_HIGHLIGHTED = vanillaSprite("page_forward_highlighted", 12, 17);
    public static final SpriteRegion PAGE_BACKWARD = vanillaSprite("page_backward", 12, 17);
    public static final SpriteRegion PAGE_BACKWARD_HIGHLIGHTED = vanillaSprite("page_backward_highlighted", 12, 17);

    // these left recipe_book.png in 1.20.2: each one is now its own file
    private static SpriteRegion vanillaSprite(String name, int width, int height) {
        ResourceLocation texture = ResourceLocation.fromNamespaceAndPath("minecraft",
            "textures/gui/sprites/recipe_book/" + name + ".png");
        return new SpriteRegion(texture, 0, 0, width, height, width, height);
    }

    private static ResourceLocation register(String dir, String fileName) {
        return ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "textures/gui/" + dir + "/" + fileName + ".png");
    }
    
    private static ResourceLocation register(String fileName) {
        return ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "textures/gui/" + fileName + ".png");
    }
}
