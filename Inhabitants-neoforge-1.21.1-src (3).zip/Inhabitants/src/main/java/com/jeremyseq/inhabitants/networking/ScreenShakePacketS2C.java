package com.jeremyseq.inhabitants.networking;

import com.jeremyseq.inhabitants.screen_shake.CameraRenderEvent;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import com.jeremyseq.inhabitants.Inhabitants;
import net.neoforged.neoforge.network.handling.IPayloadContext;


public class ScreenShakePacketS2C implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<ScreenShakePacketS2C> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "screen_shake_packet_s2c"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ScreenShakePacketS2C> STREAM_CODEC =
            CustomPacketPayload.codec(ScreenShakePacketS2C::encode, ScreenShakePacketS2C::decode);

    @Override
    public CustomPacketPayload.Type<ScreenShakePacketS2C> type() {
        return TYPE;
    }

    private final int durationTicks;

    public ScreenShakePacketS2C(int durationTicks) {
        this.durationTicks = durationTicks;
    }

    public static void encode(ScreenShakePacketS2C packet, FriendlyByteBuf buf) {
        buf.writeInt(packet.durationTicks);
    }

    public static ScreenShakePacketS2C decode(FriendlyByteBuf buf) {
        return new ScreenShakePacketS2C(buf.readInt());
    }

    public static void handle(ScreenShakePacketS2C packet, IPayloadContext ctx) {
        ctx.enqueueWork(() -> CameraRenderEvent.triggerShake(packet.durationTicks));
    }
}
