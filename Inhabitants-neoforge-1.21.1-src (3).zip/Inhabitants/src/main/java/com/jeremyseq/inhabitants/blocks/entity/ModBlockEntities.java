package com.jeremyseq.inhabitants.blocks.entity;

import com.jeremyseq.inhabitants.Inhabitants;
import com.jeremyseq.inhabitants.blocks.ModBlocks;
import com.jeremyseq.inhabitants.blocks.impaler_head.ImpalerHeadBlockEntity;

import net.minecraft.world.level.block.entity.BlockEntityType;

import net.neoforged.bus.api.*;
import net.neoforged.neoforge.registries.*;
import net.minecraft.core.registries.BuiltInRegistries;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(net.minecraft.core.registries.Registries.BLOCK_ENTITY_TYPE, Inhabitants.MODID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<ImpalerHeadBlockEntity>> IMPALER_HEAD_BLOCK_ENTITY =
            BLOCK_ENTITIES.register("impaler_head_block_entity",
                () -> BlockEntityType.Builder.of(ImpalerHeadBlockEntity::new,
                ModBlocks.IMPALER_HEAD.get(), ModBlocks.IMPALER_HEAD_DRIPSTONE.get(), ModBlocks.IMPALER_HEAD_ALBINO.get(), ModBlocks.IMPALER_HEAD_FORLORN_HOLLOWS.get(),
                ModBlocks.IMPALER_HEAD_WALL.get(), ModBlocks.IMPALER_HEAD_WALL_DRIPSTONE.get(), ModBlocks.IMPALER_HEAD_WALL_ALBINO.get(), ModBlocks.IMPALER_HEAD_WALL_FORLORN_HOLLOWS.get()).build(null));


    public static void register(IEventBus eventBus) {
        BLOCK_ENTITIES.register(eventBus);
    }

}
