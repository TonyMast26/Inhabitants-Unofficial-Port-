package com.jeremyseq.inhabitants.networking;

import com.jeremyseq.inhabitants.effects.ModEffects;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import com.jeremyseq.inhabitants.Inhabitants;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.neoforged.neoforge.network.handling.IPayloadContext;


public class AscendPacketC2S implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<AscendPacketC2S> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "ascend_packet_c2s"));

    public static final StreamCodec<RegistryFriendlyByteBuf, AscendPacketC2S> STREAM_CODEC =
            CustomPacketPayload.codec(AscendPacketC2S::encode, AscendPacketC2S::decode);

    @Override
    public CustomPacketPayload.Type<AscendPacketC2S> type() {
        return TYPE;
    }

    public AscendPacketC2S() {}

    public static void encode(AscendPacketC2S msg, FriendlyByteBuf buffer) {}

    public static AscendPacketC2S decode(FriendlyByteBuf buffer) {
        return new AscendPacketC2S();
    }

    // handles player ascend when they are inside a block
    public static void handle(AscendPacketC2S msg, IPayloadContext ctx) {

        ctx.enqueueWork(() -> {
            ServerPlayer player = (ServerPlayer) ctx.player();

            if (player != null &&
                player.hasEffect(ModEffects.IMMATERIAL)) {

                if (isInsideBlock(player)) {
                    player.teleportTo(
                        player.getX(),
                        player.getY() + 1.0D,
                        player.getZ());
                }

            }
        });
    }

    // checks if the player is inside a block
    private static boolean isInsideBlock(ServerPlayer player) {
        double px = player.getX();
        double py = player.getY();
        double pz = player.getZ();

        for (double dy : new double[]{0.1D, 0.8D, 1.62D}) {
            BlockPos pos = BlockPos.containing(px, py + dy, pz);

            if (!player.level().getBlockState(pos)
            .getCollisionShape(player.level(), pos, CollisionContext.empty()).isEmpty()) {
                return true;
            }
        }
        return false;
    }
}
