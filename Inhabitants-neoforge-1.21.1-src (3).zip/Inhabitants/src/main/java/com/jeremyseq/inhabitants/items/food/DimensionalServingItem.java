package com.jeremyseq.inhabitants.items.food;

import net.minecraft.world.item.Items;

import com.jeremyseq.inhabitants.effects.ModEffects;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.effect.MobEffectInstance;

import org.jetbrains.annotations.NotNull;

public class DimensionalServingItem extends Item {
    public DimensionalServingItem() {
        super(new Item.Properties().stacksTo(1).food(
            new FoodProperties.Builder()
            .nutrition(2)
            .saturationModifier(0.2f)
            .alwaysEdible()
            .usingConvertsTo(Items.BOWL)
            .build()));
    }

    @Override
    public @NotNull ItemStack finishUsingItem(@NotNull ItemStack stack, @NotNull Level level, @NotNull LivingEntity entity) {
        if (!level.isClientSide) {
            entity.addEffect(new MobEffectInstance(ModEffects.IMMATERIAL, 1800));
        }
        return super.finishUsingItem(stack, level, entity);
    }
}
