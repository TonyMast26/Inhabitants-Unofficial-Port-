package com.jeremyseq.inhabitants.entities.impaler.arrow;

import com.jeremyseq.inhabitants.entities.ModEntities;
import net.minecraft.core.dispenser.BlockSource;
import net.minecraft.core.Direction;
import net.minecraft.core.dispenser.DefaultDispenseItemBehavior;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;

public class ConcussionArrowDispenserBehavior extends DefaultDispenseItemBehavior {
    @Override
    protected @NotNull ItemStack execute(@NotNull BlockSource source, @NotNull ItemStack stack) {
        Level level = source.level();
        Direction direction = source.state().getValue(DispenserBlock.FACING);

        // Construct the entity properly using the registry object
        ConcussionArrowProjectile entity = ModEntities.CONCUSSION_ARROW_PROJECTILE.get()
                .create(level);

        if (entity != null) {
            // Offset the spawn point slightly in front of the dispenser face
            Vec3 spawnOffset = new Vec3(
                    direction.getStepX() * 0.6D,
                    direction.getStepY() * 0.6D,
                    direction.getStepZ() * 0.6D
            );

            Vec3 pos = source.center().add(spawnOffset);
            entity.setPos(pos);

            entity.shoot(
                    direction.getStepX(),
                    direction.getStepY(),
                    direction.getStepZ(),
                    1.5F,
                    6.0F
            );

            entity.pickup = AbstractArrow.Pickup.ALLOWED;

            level.addFreshEntity(entity);

            stack.shrink(1);
        }

        return stack;
    }
}
