package com.jeremyseq.inhabitants.networking;

import com.jeremyseq.inhabitants.events.ModEvents;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import com.jeremyseq.inhabitants.Inhabitants;
import net.minecraft.world.entity.player.Player;
import net.minecraft.client.Minecraft;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;


public class JavelinBounceSyncPacketS2C implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<JavelinBounceSyncPacketS2C> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "javelin_bounce_sync_packet_s2c"));

    public static final StreamCodec<RegistryFriendlyByteBuf, JavelinBounceSyncPacketS2C> STREAM_CODEC =
            CustomPacketPayload.codec(JavelinBounceSyncPacketS2C::encode, JavelinBounceSyncPacketS2C::decode);

    @Override
    public CustomPacketPayload.Type<JavelinBounceSyncPacketS2C> type() {
        return TYPE;
    }

    private final int combo;
    private final long lastBounceTick;

    public JavelinBounceSyncPacketS2C(int combo, long lastBounceTick) {
        this.combo = combo;
        this.lastBounceTick = lastBounceTick;
    }

    public static void encode(JavelinBounceSyncPacketS2C packet, FriendlyByteBuf buf) {
        buf.writeInt(packet.combo);
        buf.writeLong(packet.lastBounceTick);
    }

    public static JavelinBounceSyncPacketS2C decode(FriendlyByteBuf buf) {
        return new JavelinBounceSyncPacketS2C(buf.readInt(), buf.readLong());
    }

    public static void handle(JavelinBounceSyncPacketS2C packet, IPayloadContext ctx) {
        ctx.enqueueWork(() -> ClientHandler.handle(packet));
    }

    @OnlyIn(Dist.CLIENT)
    public static class ClientHandler {
        public static void handle(JavelinBounceSyncPacketS2C packet) {
            Player player = Minecraft.getInstance().player;
            if (player != null) {

                ModEvents.BOUNCE_COMBOS.put(player.getUUID(), packet.combo);
                ModEvents.LAST_BOUNCE_TICKS.put(player.getUUID(), packet.lastBounceTick);
            }
        }
    }
}
