package com.jeremyseq.inhabitants.audio;

import com.jeremyseq.inhabitants.Inhabitants;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.core.registries.BuiltInRegistries;
import net.neoforged.neoforge.registries.DeferredHolder;

public class ModSoundEvents {

    public static final DeferredRegister<SoundEvent> SOUND_EVENTS =
            DeferredRegister.create(net.minecraft.core.registries.Registries.SOUND_EVENT, Inhabitants.MODID);

    public static final DeferredHolder<SoundEvent, SoundEvent> WARPED_CLAM_CLOSING = registerSoundEvent("warped_clam.closing");
    public static final DeferredHolder<SoundEvent, SoundEvent> WARPED_CLAM_OPENING = registerSoundEvent("warped_clam.opening");
    public static final DeferredHolder<SoundEvent, SoundEvent> WARPED_CLAM_CLOSED_DAMAGE = registerSoundEvent("warped_clam.closed_damage");
    public static final DeferredHolder<SoundEvent, SoundEvent> WARPED_CLAM_OPENED_DAMAGE = registerSoundEvent("warped_clam.opened_damage");

    public static final DeferredHolder<SoundEvent, SoundEvent> BOGRE_ATTACK = registerSoundEvent("bogre.attack");
    public static final DeferredHolder<SoundEvent, SoundEvent> BOGRE_DEATH = registerSoundEvent("bogre.death");
    public static final DeferredHolder<SoundEvent, SoundEvent> BOGRE_HURT = registerSoundEvent("bogre.hurt");
    public static final DeferredHolder<SoundEvent, SoundEvent> BOGRE_IDLE = registerSoundEvent("bogre.idle");
    public static final DeferredHolder<SoundEvent, SoundEvent> BOGRE_ROAR = registerSoundEvent("bogre.roar");
    public static final DeferredHolder<SoundEvent, SoundEvent> SHOCKWAVE = registerSoundEvent("shockwave");
    public static final DeferredHolder<SoundEvent, SoundEvent> CAULDRON_GUI_OPEN = registerSoundEvent("bogre.cauldron_gui_open");

    public static final DeferredHolder<SoundEvent, SoundEvent> IMPALER_ATTACK = registerSoundEvent("impaler.attack");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPALER_DEATH = registerSoundEvent("impaler.death");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPALER_HURT = registerSoundEvent("impaler.hurt");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPALER_IDLE = registerSoundEvent("impaler.idle");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPALER_SCREAM = registerSoundEvent("impaler.scream");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPALER_SPIKES = registerSoundEvent("impaler.spikes");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMPALER_CONCUSSION = registerSoundEvent("impaler.concussion");

    public static final DeferredHolder<SoundEvent, SoundEvent> BOGRE_SONG = registerSoundEvent("disc.bogre");
    public static final DeferredHolder<SoundEvent, SoundEvent> BOGRE_HAMMER_KNOCK = registerSoundEvent("bogre.hammer_knock");
    public static final DeferredHolder<SoundEvent, SoundEvent> BOGRE_CARVING_FINISH = registerSoundEvent("bogre.carving_finish");
    public static final DeferredHolder<SoundEvent, SoundEvent> BOGRE_DEPOSIT_IN_CHEST = registerSoundEvent("bogre.deposit_in_chest");

    public static final DeferredHolder<SoundEvent, SoundEvent> BOGRE_COOKING_START = registerSoundEvent("bogre.cooking_start");
    public static final DeferredHolder<SoundEvent, SoundEvent> BOGRE_COOKING_LOOP = registerSoundEvent("bogre.cooking_loop");

    public static final DeferredHolder<SoundEvent, SoundEvent> REVERSE_GROWTH = registerSoundEvent("effects.reverse_growth");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMMATERIAL_ENTER_WALL = registerSoundEvent("effects.immaterial.enter_wall");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMMATERIAL_EXIT_WALL = registerSoundEvent("effects.immaterial.exit_wall");
    public static final DeferredHolder<SoundEvent, SoundEvent> IMMATERIAL_INSIDE = registerSoundEvent("effects.immaterial.inside");
    public static final DeferredHolder<SoundEvent, SoundEvent> CONCUSSION_BUZZ = registerSoundEvent("effects.concussion.buzz");
    
    public static final DeferredHolder<SoundEvent, SoundEvent> JAVELIN_AIMING = registerSoundEvent("item.javelin.aiming");
    public static final DeferredHolder<SoundEvent, SoundEvent> JAVELIN_BOUNCE = registerSoundEvent("item.javelin.bounce");
    public static final DeferredHolder<SoundEvent, SoundEvent> JAVELIN_LAUNCHING = registerSoundEvent("item.javelin.launch");
    public static final DeferredHolder<SoundEvent, SoundEvent> JAVELIN_ON_BLOCK_HIT = registerSoundEvent("item.javelin.on_block_hit");
    public static final DeferredHolder<SoundEvent, SoundEvent> JAVELIN_ON_ENTITY_HIT = registerSoundEvent("item.javelin.on_entity_hit");

    public static final DeferredHolder<SoundEvent, SoundEvent> DRILL_LOOP = registerSoundEvent("item.spike_drill.drilling_loop");
    public static final DeferredHolder<SoundEvent, SoundEvent> DRILL_STOPPED = registerSoundEvent("item.spike_drill.drilling_stopped");
    public static final DeferredHolder<SoundEvent, SoundEvent> DRILL_START = registerSoundEvent("item.spike_drill.drilling_start");
    public static final DeferredHolder<SoundEvent, SoundEvent> DRILL_DIG = registerSoundEvent("item.spike_drill.drilling_dig");

    private static DeferredHolder<SoundEvent, SoundEvent> registerSoundEvent(String name) {
        return SOUND_EVENTS.register(name, () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, name)));
    }

    public static void register(IEventBus eventBus) {
        SOUND_EVENTS.register(eventBus);
    }
}