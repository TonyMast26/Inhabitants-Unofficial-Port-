package com.jeremyseq.inhabitants.networking;

import com.jeremyseq.inhabitants.entities.javelin.JavelinEntity;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import com.jeremyseq.inhabitants.Inhabitants;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import net.neoforged.neoforge.network.handling.IPayloadContext;


public class JavelinBounceTriggerPacketC2S implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<JavelinBounceTriggerPacketC2S> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "javelin_bounce_trigger_packet_c2s"));

    public static final StreamCodec<RegistryFriendlyByteBuf, JavelinBounceTriggerPacketC2S> STREAM_CODEC =
            CustomPacketPayload.codec(JavelinBounceTriggerPacketC2S::encode, JavelinBounceTriggerPacketC2S::decode);

    @Override
    public CustomPacketPayload.Type<JavelinBounceTriggerPacketC2S> type() {
        return TYPE;
    }

    private final int javelinId;

    public JavelinBounceTriggerPacketC2S(int javelinId) {
        this.javelinId = javelinId;
    }

    public static void encode(JavelinBounceTriggerPacketC2S msg, FriendlyByteBuf buffer) {
        buffer.writeInt(msg.javelinId);
    }

    public static JavelinBounceTriggerPacketC2S decode(FriendlyByteBuf buffer) {
        return new JavelinBounceTriggerPacketC2S(buffer.readInt());
    }

    public static void handle(JavelinBounceTriggerPacketC2S msg, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            ServerPlayer player = (ServerPlayer) ctx.player();

            if (player != null) {
                Entity entity = player.level().getEntity(msg.javelinId);
                if (entity instanceof JavelinEntity javelin) {
                    
                    if (player.distanceToSqr(javelin) < 9.0) {
                        javelin.serverLaunch(player);
                    }
                }
            }
        });
    }
}
