package com.jeremyseq.inhabitants.items.food;

import net.minecraft.world.item.Items;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.NotNull;

public class FishSnotChowderItem extends Item {
    public FishSnotChowderItem() {
        super(new Item.Properties().stacksTo(1).food(
                new FoodProperties.Builder()
                        .nutrition(10)
                        .saturationModifier(0.8f)
                        .alwaysEdible()
                        .usingConvertsTo(Items.BOWL)
                        .build()));
    }

    @Override
    public @NotNull ItemStack finishUsingItem(@NotNull ItemStack pStack, @NotNull Level pLevel, LivingEntity pEntityLiving) {
        pEntityLiving.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 1, false, true, true));

        pEntityLiving.setAirSupply(pEntityLiving.getMaxAirSupply());

        return super.finishUsingItem(pStack, pLevel, pEntityLiving);
    }
}
