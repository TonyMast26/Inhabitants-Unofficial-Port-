package com.jeremyseq.inhabitants.potions;

import com.jeremyseq.inhabitants.Inhabitants;
import com.jeremyseq.inhabitants.effects.ModEffects;
import com.jeremyseq.inhabitants.items.ModItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.Potions;
import net.neoforged.neoforge.event.brewing.RegisterBrewingRecipesEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public class ModPotions {
    public static final DeferredRegister<Potion> POTIONS =
            DeferredRegister.create(Registries.POTION, Inhabitants.MODID);

    public static final DeferredHolder<Potion, Potion> CONCUSSION_POTION =
            POTIONS.register("concussion", () ->
                    new Potion(new MobEffectInstance(ModEffects.CONCUSSION, 300)));

    public static void register(IEventBus bus) {
        POTIONS.register(bus);
    }

    /** The potion brewing builder expands this to the splash and lingering bottles as well. */
    public static void registerBrewingRecipes(RegisterBrewingRecipesEvent event) {
        event.getBuilder().addMix(Potions.AWKWARD, ModItems.IMPALER_SPIKE.get(), CONCUSSION_POTION);
    }
}
