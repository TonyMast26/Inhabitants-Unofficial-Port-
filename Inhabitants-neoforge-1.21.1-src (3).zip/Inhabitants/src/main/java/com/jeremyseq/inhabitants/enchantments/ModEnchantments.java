package com.jeremyseq.inhabitants.enchantments;

import com.jeremyseq.inhabitants.Inhabitants;

import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;

import it.unimi.dsi.fastutil.objects.Object2IntMap;

/**
 * Enchantments are data driven since 1.21: see data/inhabitants/enchantment.
 * Only the keys live in code.
 */
public class ModEnchantments {
    public static final ResourceKey<Enchantment> DIAMOND_TIP = key("diamond_tip");
    public static final ResourceKey<Enchantment> THERMAL_CAPACITY = key("thermal_capacity");

    private static ResourceKey<Enchantment> key(String name) {
        return ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, name));
    }

    /** Level of the enchantment on the stack, without needing registry access. */
    public static int getLevel(ItemStack stack, ResourceKey<Enchantment> enchantment) {
        ItemEnchantments enchantments = stack.getTagEnchantments();
        for (Object2IntMap.Entry<Holder<Enchantment>> entry : enchantments.entrySet()) {
            if (entry.getKey().is(enchantment)) {
                return entry.getIntValue();
            }
        }
        return 0;
    }
}
