package com.jeremyseq.inhabitants.mixin;

import com.jeremyseq.inhabitants.effects.ModEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import javax.annotation.Nullable;

@Mixin(NearestAttackableTargetGoal.class)
public abstract class NearestAttackableTargetGoalMixin {

    @Shadow @Nullable
    protected LivingEntity target;

    @Inject(method = "findTarget", at = @At("TAIL"))
    private void inhabitants$ignorePlayersWithEffect(CallbackInfo ci) {
        if (this.target instanceof Player player) {

            Mob mob = ((TargetGoal) (Object) this).mob;

            // undead only
            if (!mob.getType().is(EntityTypeTags.UNDEAD)) {
                return;
            }

            if (player.hasEffect(ModEffects.UNDEAD_DISGUISE)) {
                this.target = null;
            }
        }
    }
}

