package com.jeremyseq.inhabitants.util;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

import java.util.function.Consumer;

/**
 * Small wrapper over the {@code minecraft:custom_data} component, which replaced
 * the free-form ItemStack NBT tag in 1.20.5. Keeps the original key names.
 */
public final class StackData {
    private StackData() {}

    public static boolean has(ItemStack stack) {
        return stack.has(DataComponents.CUSTOM_DATA);
    }

    /** Returns a copy: mutating it does not affect the stack, use {@link #edit}. */
    public static CompoundTag get(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
    }

    public static void edit(ItemStack stack, Consumer<CompoundTag> editor) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack, editor);
    }

    public static void putInt(ItemStack stack, String key, int value) {
        edit(stack, tag -> tag.putInt(key, value));
    }

    public static void putLong(ItemStack stack, String key, long value) {
        edit(stack, tag -> tag.putLong(key, value));
    }

    public static void putBoolean(ItemStack stack, String key, boolean value) {
        edit(stack, tag -> tag.putBoolean(key, value));
    }

    public static void putFloat(ItemStack stack, String key, float value) {
        edit(stack, tag -> tag.putFloat(key, value));
    }

    public static void putString(ItemStack stack, String key, String value) {
        edit(stack, tag -> tag.putString(key, value));
    }
}
