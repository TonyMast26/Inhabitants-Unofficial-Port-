package com.jeremyseq.inhabitants.items;

import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.decoration.PaintingVariant;
import net.minecraft.world.item.component.CustomData;

import com.jeremyseq.inhabitants.util.StackData;
import com.jeremyseq.inhabitants.Inhabitants;
import com.jeremyseq.inhabitants.enchantments.ModEnchantments;
import com.jeremyseq.inhabitants.entities.warped_clam.WarpedClamEntity;
import com.jeremyseq.inhabitants.paintings.ModPaintings;

import com.jeremyseq.inhabitants.potions.ModPotions;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.*;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.enchantment.*;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public class ModCreativeModeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Inhabitants.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> INHABITANTS_TAB = CREATIVE_MODE_TABS.register("inhabitants_tab",
            () -> CreativeModeTab.builder().icon(() -> new ItemStack(ModItems.CREATIVE_TAB.get()))
                    .title(Component.translatable("creativetab.inhabitants_tab"))
                    .displayItems((pParameters, pOutput) -> {

                        // spawn eggs
                        pOutput.accept(ModItems.BOGRE_SPAWN_EGG.get());
                        pOutput.accept(ModItems.IMPALER_SPAWN_EGG.get());

                        ItemStack warped_clam_ender = new ItemStack(ModItems.WARPED_CLAM_ITEM.get());
                        StackData.putInt(warped_clam_ender, "variant", WarpedClamEntity.Variant.ENDER.ordinal());
                        StackData.putBoolean(warped_clam_ender, "has_pearl", true);
                        pOutput.accept(warped_clam_ender);

                        ItemStack warped_clam_camouflage = new ItemStack(ModItems.WARPED_CLAM_ITEM.get());
                        StackData.putInt(warped_clam_camouflage, "variant", WarpedClamEntity.Variant.CAMOUFLAGE.ordinal());
                        StackData.putBoolean(warped_clam_camouflage, "has_pearl", true);
                        pOutput.accept(warped_clam_camouflage);

                        ItemStack warped_clam_amaranth = new ItemStack(ModItems.WARPED_CLAM_ITEM.get());
                        StackData.putInt(warped_clam_amaranth, "variant", WarpedClamEntity.Variant.AMARANTH.ordinal());
                        StackData.putBoolean(warped_clam_amaranth, "has_pearl", true);
                        pOutput.accept(warped_clam_amaranth);

                        ItemStack warped_clam_voidblue = new ItemStack(ModItems.WARPED_CLAM_ITEM.get());
                        StackData.putInt(warped_clam_voidblue, "variant", WarpedClamEntity.Variant.VOID_BLUE.ordinal());
                        StackData.putBoolean(warped_clam_voidblue, "has_pearl", true);
                        pOutput.accept(warped_clam_voidblue);

                        // mob drops / materials
                        pOutput.accept(ModItems.IMPALER_SPIKE.get());

                        // weapons / tools
                        pOutput.accept(ModItems.GIANT_BONE.get());
                        pOutput.accept(ModItems.JAVELIN.get());
                        pOutput.accept(ModItems.SPIKE_DRILL.get());
                        pOutput.accept(ModItems.CONCUSSION_ARROW.get());

                        // food
                        pOutput.accept(ModItems.FISH_SNOT_CHOWDER.get());
                        pOutput.accept(ModItems.UNCANNY_POTTAGE.get());
                        pOutput.accept(ModItems.BAKED_BRAINS.get());
                        pOutput.accept(ModItems.MARINATED_SPIDER.get());
                        pOutput.accept(ModItems.DIMENSIONAL_SERVING.get());

                        // decorative
                        pOutput.accept(ModItems.IMPALER_HEAD.get());
                        pOutput.accept(ModItems.IMPALER_HEAD_DRIPSTONE.get());
                        pOutput.accept(ModItems.IMPALER_HEAD_ALBINO.get());
                        pOutput.accept(ModItems.IMPALER_HEAD_FORLORN_HOLLOWS.get());

                        // misc special items
                        pOutput.accept(ModItems.MUSIC_DISC_BOGRE.get());

                        // potions
                        pOutput.accept(PotionContents.createItemStack(Items.POTION, ModPotions.CONCUSSION_POTION));
                        pOutput.accept(PotionContents.createItemStack(Items.SPLASH_POTION, ModPotions.CONCUSSION_POTION));
                        pOutput.accept(PotionContents.createItemStack(Items.LINGERING_POTION, ModPotions.CONCUSSION_POTION));

                        // enchantments
                        addEnchantedBook(pParameters.holders(), ModEnchantments.DIAMOND_TIP, 1, pOutput);
                        addEnchantedBook(pParameters.holders(), ModEnchantments.THERMAL_CAPACITY, 1, pOutput);

                        // paintings
                        addPainting(pParameters.holders(), ModPaintings.MY_PRECIOUS, pOutput);
                        addPainting(pParameters.holders(), ModPaintings.ENDERMANS_LAST_DAY, pOutput);
                    })
                    .build());

    public static void register(IEventBus eventBus) {
        CREATIVE_MODE_TABS.register(eventBus);
    }

    private static void addPainting(HolderLookup.Provider holders, ResourceKey<PaintingVariant> variant, CreativeModeTab.Output output) {
        holders.lookup(Registries.PAINTING_VARIANT).flatMap(lookup -> lookup.get(variant)).ifPresent(holder -> {
            ItemStack stack = new ItemStack(Items.PAINTING);
            CompoundTag entityData = new CompoundTag();
            entityData.putString("id", "minecraft:painting");
            entityData.putString("variant", variant.location().toString());
            stack.set(DataComponents.ENTITY_DATA, CustomData.of(entityData));
            output.accept(stack);
        });
    }

    private static void addEnchantedBook(HolderLookup.Provider holders, ResourceKey<Enchantment> enchantment, int level, CreativeModeTab.Output output) {
        holders.lookup(Registries.ENCHANTMENT).flatMap(lookup -> lookup.get(enchantment)).ifPresent(holder ->
                output.accept(EnchantedBookItem.createForEnchantment(new EnchantmentInstance(holder, level))));
    }
}
