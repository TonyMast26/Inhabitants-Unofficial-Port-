package com.jeremyseq.inhabitants.particles;

import com.jeremyseq.inhabitants.Inhabitants;
import net.minecraft.core.particles.*;
import net.minecraft.core.registries.Registries;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.registries.*;
import net.minecraft.core.registries.BuiltInRegistries;

@EventBusSubscriber(modid = Inhabitants.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ModParticles {
    public static final DeferredRegister<ParticleType<?>> PARTICLES =
            DeferredRegister.create(Registries.PARTICLE_TYPE, Inhabitants.MODID);

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> IMPALER_SCREAM =
            PARTICLES.register("impaler_scream",
                    () -> new SimpleParticleType(false));

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> WARPED_CLAM_PEARL_AMBIENCE =
            PARTICLES.register("warped_clam_pearl_ambience",
                    () -> new SimpleParticleType(false));

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> WARPED_CLAM_INDICATOR_ENDER =
            PARTICLES.register("warped_clam_indicator_ender",
                    () -> new SimpleParticleType(false));
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> WARPED_CLAM_INDICATOR_CAMOUFLAGE =
            PARTICLES.register("warped_clam_indicator_camouflage",
                    () -> new SimpleParticleType(false));
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> WARPED_CLAM_INDICATOR_VOIDBLUE =
            PARTICLES.register("warped_clam_indicator_voidblue",
                    () -> new SimpleParticleType(false));
    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> WARPED_CLAM_INDICATOR_AMARANTH =
            PARTICLES.register("warped_clam_indicator_amaranth",
                    () -> new SimpleParticleType(false));

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> ROAR_EFFECT =
            PARTICLES.register("roar_effect",
                    () -> new SimpleParticleType(true));

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> SONIC_WAVE =
            PARTICLES.register("sonic_wave",
                    () -> new SimpleParticleType(true));

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> SHOCKWAVE =
            PARTICLES.register("shockwave",
                    () -> new SimpleParticleType(true));

    public static final DeferredHolder<ParticleType<?>, SimpleParticleType> ABRACADABRA =
            PARTICLES.register("abracadabra",
                    () -> new SimpleParticleType(false));

    @SubscribeEvent
    public static void registerParticles(RegisterParticleProvidersEvent evt) {
        evt.registerSpriteSet(ModParticles.IMPALER_SCREAM.get(), ScreamParticle.Factory::new);
        evt.registerSpriteSet(ModParticles.WARPED_CLAM_PEARL_AMBIENCE.get(), WarpedClamPearlAmbienceParticle.Factory::new);
        evt.registerSpriteSet(ModParticles.WARPED_CLAM_INDICATOR_ENDER.get(), WarpedClamPearlIndicatorParticle.Factory::new);
        evt.registerSpriteSet(ModParticles.WARPED_CLAM_INDICATOR_CAMOUFLAGE.get(), WarpedClamPearlIndicatorParticle.Factory::new);
        evt.registerSpriteSet(ModParticles.WARPED_CLAM_INDICATOR_VOIDBLUE.get(), WarpedClamPearlIndicatorParticle.Factory::new);
        evt.registerSpriteSet(ModParticles.WARPED_CLAM_INDICATOR_AMARANTH.get(), WarpedClamPearlIndicatorParticle.Factory::new);
        evt.registerSpriteSet(ModParticles.ROAR_EFFECT.get(), RoarEffectParticle.Factory::new);
        evt.registerSpriteSet(ModParticles.SONIC_WAVE.get(), SonicWaveParticle.Factory::new);
        evt.registerSpriteSet(ModParticles.SHOCKWAVE.get(), ShockwaveParticle.Factory::new);
        evt.registerSpriteSet(ModParticles.ABRACADABRA.get(), AbracadabraParticle.Factory::new);
    }
}