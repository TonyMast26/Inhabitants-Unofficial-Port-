package com.jeremyseq.inhabitants.networking;

import com.jeremyseq.inhabitants.networking.bogre.*;

import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;

import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class ModNetworking {
    private static final String PROTOCOL_VERSION = "1.0";

    public static <T extends CustomPacketPayload> void sendToServer(T message) {
        PacketDistributor.sendToServer(message);
    }

    public static <T extends CustomPacketPayload> void sendToPlayer(T message, ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, message);
    }

    /** Registered on the mod event bus from the main mod class. */
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(PROTOCOL_VERSION);

        registrar.playToServer(BogreSkillKeyframePacketC2S.TYPE, BogreSkillKeyframePacketC2S.STREAM_CODEC, BogreSkillKeyframePacketC2S::handle);
        registrar.playToServer(BogreRecipePacketC2S.TYPE, BogreRecipePacketC2S.STREAM_CODEC, BogreRecipePacketC2S::handle);
        registrar.playToServer(AscendPacketC2S.TYPE, AscendPacketC2S.STREAM_CODEC, AscendPacketC2S::handle);
        registrar.playToServer(DrillDamagePacketC2S.TYPE, DrillDamagePacketC2S.STREAM_CODEC, DrillDamagePacketC2S::handle);
        registrar.playToServer(JavelinBounceTriggerPacketC2S.TYPE, JavelinBounceTriggerPacketC2S.STREAM_CODEC, JavelinBounceTriggerPacketC2S::handle);
        registrar.playToClient(ScreenShakePacketS2C.TYPE, ScreenShakePacketS2C.STREAM_CODEC, ScreenShakePacketS2C::handle);
        registrar.playToClient(ShockwaveParticlePacketS2C.TYPE, ShockwaveParticlePacketS2C.STREAM_CODEC, ShockwaveParticlePacketS2C::handle);
        registrar.playToClient(TinnitusPacketS2C.TYPE, TinnitusPacketS2C.STREAM_CODEC, TinnitusPacketS2C::handle);
        registrar.playToClient(BogreRecipePacketS2C.TYPE, BogreRecipePacketS2C.STREAM_CODEC, BogreRecipePacketS2C::handle);
        registrar.playToClient(JavelinBounceSyncPacketS2C.TYPE, JavelinBounceSyncPacketS2C.STREAM_CODEC, JavelinBounceSyncPacketS2C::handle);
    }
}
