package com.jeremyseq.inhabitants.compat;

import com.mojang.serialization.MapCodec;
import net.neoforged.neoforge.common.world.BiomeModifier;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;
import java.util.function.Supplier;
import net.neoforged.neoforge.registries.NeoForgeRegistries;

import static com.jeremyseq.inhabitants.Inhabitants.MODID;

public class ModBiomeModifiers {
    public static final DeferredRegister<MapCodec<? extends BiomeModifier>>
            BIOME_MODIFIER_SERIALIZERS =
            DeferredRegister.create(
                    NeoForgeRegistries.Keys.BIOME_MODIFIER_SERIALIZERS,
                    MODID);

    public static final Supplier<MapCodec<ImpalerForlornHollowsBiomeModifier>>
            IMPALER_FORLORN_HOLLOWS =
            BIOME_MODIFIER_SERIALIZERS.register(
                    "impaler_forlorn_hollows",
                    () -> MapCodec.unit(ImpalerForlornHollowsBiomeModifier::new));

    public static void register(IEventBus eventBus) {
        BIOME_MODIFIER_SERIALIZERS.register(eventBus);
    }
}
