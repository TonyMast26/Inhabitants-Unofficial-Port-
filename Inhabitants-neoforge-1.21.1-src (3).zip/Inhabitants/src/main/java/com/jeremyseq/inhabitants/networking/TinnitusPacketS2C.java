package com.jeremyseq.inhabitants.networking;

import com.jeremyseq.inhabitants.audio.ModSoundEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import com.jeremyseq.inhabitants.Inhabitants;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.network.handling.IPayloadContext;


public record TinnitusPacketS2C() implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<TinnitusPacketS2C> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "tinnitus_packet_s2c"));

    public static final StreamCodec<RegistryFriendlyByteBuf, TinnitusPacketS2C> STREAM_CODEC =
            CustomPacketPayload.codec(TinnitusPacketS2C::encode, TinnitusPacketS2C::decode);

    @Override
    public CustomPacketPayload.Type<TinnitusPacketS2C> type() {
        return TYPE;
    }


    public static void encode(TinnitusPacketS2C packet, FriendlyByteBuf buf) {}

    public static TinnitusPacketS2C decode(FriendlyByteBuf buf) {
        return new TinnitusPacketS2C();
    }

    public static void handle(TinnitusPacketS2C packet, IPayloadContext ctx) {
        ctx.enqueueWork(ClientHandler::playTinnitus);
    }

    @OnlyIn(Dist.CLIENT)
    public static class ClientHandler {
        public static void playTinnitus() {
            Minecraft.getInstance().getSoundManager().play(
                    SimpleSoundInstance.forUI(ModSoundEvents.IMPALER_CONCUSSION.get(), 1.0f));
        }
    }
}