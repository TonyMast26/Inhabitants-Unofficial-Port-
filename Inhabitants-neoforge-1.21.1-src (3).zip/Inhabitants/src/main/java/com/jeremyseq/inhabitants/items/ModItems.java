package com.jeremyseq.inhabitants.items;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.registries.DeferredHolder;

import com.jeremyseq.inhabitants.Inhabitants;
import com.jeremyseq.inhabitants.entities.ModEntities;
import com.jeremyseq.inhabitants.items.food.*;
import com.jeremyseq.inhabitants.items.javelin.JavelinItem;
import com.jeremyseq.inhabitants.blocks.ModBlocks;

import net.minecraft.world.item.*;
import net.minecraft.core.Direction;

import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.*;
import net.minecraft.core.registries.BuiltInRegistries;

public class ModItems {
    public static final ResourceKey<JukeboxSong> BOGRE_JUKEBOX_SONG = ResourceKey.create(
            Registries.JUKEBOX_SONG, ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "bogre"));

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(net.minecraft.core.registries.Registries.ITEM, Inhabitants.MODID);

    public static final DeferredHolder<Item, Item> GIANT_BONE = ITEMS.register("giant_bone",
            GiantBoneItem::new);

    public static final DeferredHolder<Item, Item> FISH_SNOT_CHOWDER = ITEMS.register("fish_snot_chowder",
            FishSnotChowderItem::new);
    public static final DeferredHolder<Item, Item> UNCANNY_POTTAGE = ITEMS.register("uncanny_pottage",
            UncannyPottageItem::new);
    public static final DeferredHolder<Item, Item> MARINATED_SPIDER = ITEMS.register("marinated_spider",
            MarinatedSpiderItem::new);
    public static final DeferredHolder<Item, Item> BAKED_BRAINS = ITEMS.register("baked_brains",
            BakedBrainsItem::new);
    public static final DeferredHolder<Item, Item> DIMENSIONAL_SERVING = ITEMS.register("dimensional_serving",
            DimensionalServingItem::new);

    public static final DeferredHolder<Item, Item> CREATIVE_TAB = ITEMS.register("creative_tab",
            () -> new Item(new Item.Properties().stacksTo(1)));

    public static final DeferredHolder<Item, Item> BOGRE_SPAWN_EGG = ITEMS.register("bogre_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.BOGRE, 0x36786A, 0xA35242, new Item.Properties()));

    public static final DeferredHolder<Item, Item> WARPED_CLAM_ITEM = ITEMS.register("warped_clam",
            () -> new WarpedClamItem(new Item.Properties()));

    public static final DeferredHolder<Item, Item> IMPALER_SPAWN_EGG = ITEMS.register("impaler_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.IMPALER, 0x969090, 0x9d9382, new Item.Properties()));

    public static final DeferredHolder<Item, Item> IMPALER_SPIKE = ITEMS.register("impaler_spike",
            () -> new Item(new Item.Properties()));

    public static final DeferredHolder<Item, Item> MUSIC_DISC_BOGRE = ITEMS.register("music_disc_bogre",
            () -> new Item(new Item.Properties().stacksTo(1).rarity(Rarity.RARE).jukeboxPlayable(BOGRE_JUKEBOX_SONG)));

    public static final DeferredHolder<Item, Item> JAVELIN = ITEMS.register("javelin",
            () -> new JavelinItem(new Item.Properties().stacksTo(16)));

    /* this item show's ONLY in JEI, so don't dream getting it in-game *kiss*, *kiss* */
    public static final DeferredHolder<Item, Item> BOGRE_CAULDRON = ITEMS.register("bogre_cauldron",
            () -> new Item(new Item.Properties()));
    /* the end of the joke, i hope */

    public static final DeferredHolder<Item, Item> SPIKE_DRILL = ITEMS.register("spike_drill",
            () -> new SpikeDrillItem(new Item.Properties().durability(2342)));

    public static final DeferredHolder<Item, Item> IMPALER_HEAD = ITEMS.register("impaler_head",
            () -> new StandingAndWallBlockItem(ModBlocks.IMPALER_HEAD.get(),
            ModBlocks.IMPALER_HEAD_WALL.get(),
            new Item.Properties().rarity(Rarity.UNCOMMON),
            Direction.DOWN));
    public static final DeferredHolder<Item, Item> IMPALER_HEAD_DRIPSTONE = ITEMS.register("impaler_head_dripstone",
            () -> new StandingAndWallBlockItem(ModBlocks.IMPALER_HEAD_DRIPSTONE.get(),
            ModBlocks.IMPALER_HEAD_WALL_DRIPSTONE.get(),
            new Item.Properties().rarity(Rarity.UNCOMMON),
            Direction.DOWN));
    public static final DeferredHolder<Item, Item> IMPALER_HEAD_ALBINO = ITEMS.register("impaler_head_albino",
            () -> new StandingAndWallBlockItem(ModBlocks.IMPALER_HEAD_ALBINO.get(),
                    ModBlocks.IMPALER_HEAD_WALL_ALBINO.get(),
                    new Item.Properties().rarity(Rarity.UNCOMMON),
                    Direction.DOWN));
    public static final DeferredHolder<Item, Item> IMPALER_HEAD_FORLORN_HOLLOWS = ITEMS.register("impaler_head_forlorn_hollows",
            () -> new StandingAndWallBlockItem(ModBlocks.IMPALER_HEAD_FORLORN_HOLLOWS.get(),
                    ModBlocks.IMPALER_HEAD_WALL_FORLORN_HOLLOWS.get(),
                    new Item.Properties().rarity(Rarity.UNCOMMON),
                    Direction.DOWN));

    public static final DeferredHolder<Item, Item> CONCUSSION_ARROW = ITEMS.register("concussion_arrow",
            () -> new ConcussionArrowItem(new Item.Properties()));

    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
