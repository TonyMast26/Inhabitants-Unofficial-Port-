package com.jeremyseq.inhabitants.screen_shake;

import com.jeremyseq.inhabitants.Inhabitants;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ViewportEvent;

/**
 * The level is no longer rendered through a shared PoseStack since 1.20.5, so the shake is
 * applied to the camera angles. The original screen space offsets are converted to yaw and pitch.
 */
@EventBusSubscriber(modid = Inhabitants.MODID, value = Dist.CLIENT)
public class CameraRenderEvent {
    private static final float OFFSET_TO_DEGREES = 2.5f;

    private static int shakeTicks = 0;
    private static int totalShakeTicks = 0;

    private static float targetX, targetY, targetRot;
    private static float currentX, currentY, currentRot;
    private static int noiseTick = 0;

    @SubscribeEvent(priority = EventPriority.LOW)
    public static void onComputeCameraAngles(ViewportEvent.ComputeCameraAngles event) {
        if (shakeTicks <= 0) return;

        float partialTick = (float) event.getPartialTick();

        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;

        // change targets occasionally (every 3 ticks)
        if (noiseTick++ % 3 == 0) {
            targetX = (Minecraft.getInstance().level.random.nextFloat() - 0.5f) * 0.6f;
            targetY = (Minecraft.getInstance().level.random.nextFloat() - 0.5f) * 0.4f;
            targetRot = (Minecraft.getInstance().level.random.nextFloat() - 0.5f) * 2.5f;
        }

        // smooth toward target (critical!)
        currentX += (targetX - currentX) * 0.25f;
        currentY += (targetY - currentY) * 0.25f;
        currentRot += (targetRot - currentRot) * 0.25f;

        // fade curve
        float progress = 1f - ((shakeTicks - partialTick) / totalShakeTicks);
        float fade = (float) Math.sin(Math.PI * progress);

        // apply
        event.setYaw(event.getYaw() + currentX * fade * OFFSET_TO_DEGREES);
        event.setPitch(event.getPitch() + currentY * fade * OFFSET_TO_DEGREES);
        event.setRoll(event.getRoll() + currentRot * fade);

        shakeTicks--;
    }

    public static void triggerShake(int durationTicks) {
        shakeTicks = durationTicks;
        totalShakeTicks = durationTicks;
    }
}
