package com.jeremyseq.inhabitants.networking.bogre;

import com.jeremyseq.inhabitants.entities.bogre.BogreEntity;
import com.jeremyseq.inhabitants.entities.bogre.ai.BogreAi;
import com.jeremyseq.inhabitants.entities.bogre.skill.BogreSkills;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import com.jeremyseq.inhabitants.Inhabitants;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.neoforged.neoforge.network.handling.IPayloadContext;


public class BogreSkillKeyframePacketC2S implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<BogreSkillKeyframePacketC2S> TYPE =
            new CustomPacketPayload.Type<>(ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, "bogre_skill_keyframe_packet_c2s"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BogreSkillKeyframePacketC2S> STREAM_CODEC =
            CustomPacketPayload.codec(BogreSkillKeyframePacketC2S::encode, BogreSkillKeyframePacketC2S::decode);

    @Override
    public CustomPacketPayload.Type<BogreSkillKeyframePacketC2S> type() {
        return TYPE;
    }

    private final int bogreId;
    private final String keyframeName;

    public BogreSkillKeyframePacketC2S(int bogreId, String keyframeName) {
        this.bogreId = bogreId;
        this.keyframeName = keyframeName;
    }

    public static void encode(BogreSkillKeyframePacketC2S packet, FriendlyByteBuf buffer) {
        buffer.writeInt(packet.bogreId);
        buffer.writeUtf(packet.keyframeName);
    }

    public static BogreSkillKeyframePacketC2S decode(FriendlyByteBuf buffer) {
        return new BogreSkillKeyframePacketC2S(buffer.readInt(), buffer.readUtf());
    }

    public static void handle(BogreSkillKeyframePacketC2S packet, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            ServerPlayer player = (ServerPlayer) ctx.player();
            if (player != null) {
                Entity entity = player.level().getEntity(packet.bogreId);
                if (entity instanceof BogreEntity bogre) {
                    if (bogre.getAIState() == BogreAi.State.SKILLING) {
                        BogreAi.SkillingState state = bogre.getCraftingState();
                        
                        if (state == BogreAi.SkillingState.CARVING) {
                            BogreSkills.CARVING.keyframeTriggered(bogre, packet.keyframeName);
                        } else if (state == BogreAi.SkillingState.TRANSFORMATION) {
                            BogreSkills.TRANSFORMATION.keyframeTriggered(bogre, packet.keyframeName);
                        }
                    }
                }
            }
        });
    }
}
