package com.jeremyseq.inhabitants.paintings;

import com.jeremyseq.inhabitants.Inhabitants;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.decoration.PaintingVariant;

/** Painting variants are data driven since 1.21: see data/inhabitants/painting_variant. */
public class ModPaintings {
    public static final ResourceKey<PaintingVariant> MY_PRECIOUS = key("my_precious");
    public static final ResourceKey<PaintingVariant> ENDERMANS_LAST_DAY = key("endermans_last_day");

    private static ResourceKey<PaintingVariant> key(String name) {
        return ResourceKey.create(Registries.PAINTING_VARIANT, ResourceLocation.fromNamespaceAndPath(Inhabitants.MODID, name));
    }
}
