package com.jeremyseq.inhabitants.blocks;

import com.jeremyseq.inhabitants.entities.ModEntities;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

/** Capabilities are registered up front in NeoForge instead of being exposed by the objects themselves. */
public class ModCapabilities {
    public static void register(RegisterCapabilitiesEvent event) {
        event.registerEntity(Capabilities.ItemHandler.ENTITY, ModEntities.BOGRE_CAULDRON.get(),
                (cauldron, context) -> cauldron.getItemHandler());
        event.registerEntity(Capabilities.ItemHandler.ENTITY_AUTOMATION, ModEntities.BOGRE_CAULDRON.get(),
                (cauldron, context) -> cauldron.getItemHandler());
    }
}
