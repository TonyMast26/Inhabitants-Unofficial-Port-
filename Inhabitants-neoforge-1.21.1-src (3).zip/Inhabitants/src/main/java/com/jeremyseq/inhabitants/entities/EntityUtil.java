package com.jeremyseq.inhabitants.entities;

import com.jeremyseq.inhabitants.particles.ModParticles;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.common.ItemAbilities;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.function.Predicate;

public class EntityUtil {
    /** Reach used by mobs before 1.20.5; {@code Mob#getMeleeAttackRangeSqr} no longer exists. */
    public static double getMeleeAttackRangeSqr(LivingEntity attacker, LivingEntity target) {
        double width = attacker.getBbWidth() * 2.0F;
        return width * width + target.getBbWidth();
    }

    public static void throwItemStack(Level level, Entity entity, ItemStack stack, float speed, float upwardBias) {
        if (level.isClientSide || stack.isEmpty() || entity == null) return;
        throwItemStack(level,
        new Vec3(entity.getX(), entity.getEyeY(), entity.getZ()),
        entity.getLookAngle(), stack, speed, upwardBias);
    }

    public static void throwItemStack(Level level, Vec3 pos, Vec3 direction, ItemStack stack, float speed, float upwardBias) {
        if (level.isClientSide || stack.isEmpty()) return;

        ItemEntity itemEntity = new ItemEntity(
                level,
                pos.x,
                pos.y,
                pos.z,
                stack.copy()
        );

        // direction in front of the entity
        Vec3 look = direction.normalize();
        Vec3 motion = look.scale(speed).add(0, upwardBias, 0);
        itemEntity.setDeltaMovement(motion);

        // set pickup delay like a player-thrown item
        itemEntity.setDefaultPickUpDelay();

        level.addFreshEntity(itemEntity);
    }

    public static void shockwave(LivingEntity user, double shockwave_radius, float shockwave_damage, Predicate<LivingEntity> ignore) {
        shockwave(user, shockwave_radius, shockwave_damage, ignore, true);
    }

    /**
     * Standard shockwave effect that damages and knocks back entities around the user.
     *
     * @param shockwave_damage damage at the center of the shockwave
     */
    public static void shockwave(LivingEntity user, double shockwave_radius, float shockwave_damage, Predicate<LivingEntity> ignore, boolean playSound) {
        AABB shockwaveArea = new AABB(user.getX() - shockwave_radius, user.getY() - 1, user.getZ() - shockwave_radius,
                user.getX() + shockwave_radius, user.getY() + 2, user.getZ() + shockwave_radius);
        List<LivingEntity> affectedEntities = user.level().getEntitiesOfClass(LivingEntity.class, shockwaveArea,
                entity -> !entity.isSpectator() && entity.isAlive());

        for (LivingEntity affected : affectedEntities) {
            if (ignore.test(affected)) {
                continue;
            }
            if (affected instanceof Player player) {
                if (player.isCreative()) {
                    continue;
                }
            }

            double distanceSq = affected.distanceToSqr(user.getX(), affected.getY(), user.getZ());
            double dx = affected.getX() - user.getX();
            double dz = affected.getZ() - user.getZ();
            double distance = Math.sqrt(distanceSq);
            if (distance > shockwave_radius) {
                continue;
            }
            if (distance > 0.1) {
                double strength = (shockwave_radius - distance) / shockwave_radius;
                affected.knockback(strength * 20, -dx / distance, -dz / distance);

                // do damage, falling off based on distance
                // this has a max damage of shockwave_damage at the center and falls off to 0 at the edge
                float damage = (float) (shockwave_damage * (1 - Math.min(distance / shockwave_radius, 1)));

                // if the affected entity is a player blocking with a shield, damage the shield instead
                if (affected instanceof Player player && player.isBlocking() && isFacing(user, player)) {
                    int shieldDamage = (int) Math.max(30, damage*3);
                    damageShield(player, shieldDamage);

                    // stop blocking for 5 seconds if using a shield
                    ItemStack shieldStack = player.getUseItem();
                    if (shieldStack.canPerformAction(ItemAbilities.SHIELD_BLOCK)) {
                        player.stopUsingItem();
                        player.getCooldowns().addCooldown(shieldStack.getItem(), 100);
                    }

                    player.level().playSound(null, player.blockPosition(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1.0F, 0.8F + player.getRandom().nextFloat() * 0.2F);
                }

                if (user instanceof Player player) {
                    affected.hurt(player.damageSources().playerAttack(player), damage);
                } else {
                    affected.hurt(user.damageSources().mobAttack(user), damage);
                }
            }
        }

        // add visual and sound effects for the shockwave
        if (user.level() instanceof ServerLevel serverLevel) {
            if (playSound) {
                user.playSound(SoundEvents.GENERIC_EXPLODE.value(), 1.0f, 1.0f);
            }

            // cloud ring
            for (int i = 0; i < 20; i++) {
                double angle = 2 * Math.PI * i / 20;
                double px = user.getX() + Math.cos(angle) * shockwave_radius;
                double pz = user.getZ() + Math.sin(angle) * shockwave_radius;
                serverLevel.sendParticles(ParticleTypes.CLOUD, px, user.getY(), pz, 1, 0, 0, 0, 0);
            }

            // crack-like particles around center
            BlockState state = user.getBlockStateOn();
            BlockParticleOption crackParticles = new BlockParticleOption(ParticleTypes.BLOCK, state);
            for (int i = 0; i < 40; i++) {
                double angle = 2 * Math.PI * i / 40;
                double radius = shockwave_radius * (0.3 + 0.7 * Math.random()); // inner to outer ring
                double px = user.getX() + Math.cos(angle) * radius;
                double pz = user.getZ() + Math.sin(angle) * radius;
                double py = user.getY();

                serverLevel.sendParticles(crackParticles, px, py, pz, 5, 0.1, 0.01, 0.1, 0.05);
            }
        }
    }

    /**
     * @return true if defender’s look vector is roughly toward attacker (120deg cone)
     */
    public static boolean isFacing(LivingEntity attacker, Player defender) {
        Vec3 toAttacker = attacker.position().subtract(defender.position()).normalize();
        return defender.getLookAngle().normalize().dot(toAttacker) > 0.5D;
    }

    public static void damageShield(Player player, int amount) {
        for (InteractionHand hand : InteractionHand.values()) {
            ItemStack stack = player.getItemInHand(hand);
            if (stack.canPerformAction(ItemAbilities.SHIELD_BLOCK)) {
                stack.hurtAndBreak(amount, player, LivingEntity.getSlotForHand(hand));
                break;
            }
        }
    }

    public static void screamParticles(ClientLevel level, Vec3 pos, Vec3 lookAngle) {
        screamParticles(level, pos, lookAngle, 1.0F);
    }

    public static void screamParticles(ClientLevel level, Vec3 pos, Vec3 lookAngle, double screamSpeed) {
        screamParticles(level, pos, lookAngle, screamSpeed, 0, 4.0);
    }

    public static void screamParticles(ClientLevel level, Vec3 pos, Vec3 lookAngle, double screamSpeed, double scale) {
        screamParticles(level, pos, lookAngle, screamSpeed, scale, 4.0);
    }

    public static void screamParticles(ClientLevel level, Vec3 pos, Vec3 lookAngle, double screamSpeed, double scale, double forwardOffset) {
        lookAngle = new Vec3(lookAngle.x, 0, lookAngle.z).normalize();
        pos = pos.add(lookAngle.scale(forwardOffset));
        float yaw = (float) Math.atan2(lookAngle.z, lookAngle.x);
        level.addParticle(ModParticles.IMPALER_SCREAM.get(), pos.x, pos.y, pos.z, screamSpeed, yaw, scale);
    }

    public static boolean isInScreamBox(LivingEntity source, Entity target, double forwardDist, double sideDist, double heightDist) {
        Vec3 mouth = source.getEyePosition();
        Vec3 look = source.getLookAngle().normalize();
        Vec3 toTarget = target.getBoundingBox().getCenter().subtract(mouth);

        double fwd = toTarget.dot(look);
        if (fwd < 0 || fwd > forwardDist) return false;

        Vec3 sideLook = new Vec3(-look.z, 0, look.x).normalize();
        double side = Math.abs(toTarget.dot(sideLook));
        if (side > sideDist / 2.0) return false;

        double vert = Math.abs(toTarget.y);
        if (vert > heightDist / 2.0) return false;

        return true;
    }
}
