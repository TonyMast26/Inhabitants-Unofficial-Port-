package com.jeremyseq.inhabitants.gui;

import com.jeremyseq.inhabitants.gui.cauldron.CauldronMenu;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.AbstractContainerMenu;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.minecraft.core.registries.BuiltInRegistries;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.network.IContainerFactory;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

public class ModMenuTypes {
    public static final DeferredRegister<MenuType<?>> MENU_TYPES =
            DeferredRegister.create(net.minecraft.core.registries.Registries.MENU, "inhabitants");

    public static final DeferredHolder<MenuType<?>, MenuType<CauldronMenu>> CAULDRON_MENU =
        registerMenuType(CauldronMenu::new, "cauldron_menu");

    private static <T extends AbstractContainerMenu> DeferredHolder<MenuType<?>, MenuType<T>>
        registerMenuType(IContainerFactory<T> factory, String name) {
        
        return MENU_TYPES.register(name, () -> IMenuTypeExtension.create(factory));
    }
}
