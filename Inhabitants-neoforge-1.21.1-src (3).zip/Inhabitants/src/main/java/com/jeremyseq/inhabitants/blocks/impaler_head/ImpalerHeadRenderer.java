package com.jeremyseq.inhabitants.blocks.impaler_head;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.*;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RotationSegment;

import software.bernie.geckolib.cache.object.*;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.renderer.GeoBlockRenderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;

import org.joml.Matrix4f;

public class ImpalerHeadRenderer extends GeoBlockRenderer<ImpalerHeadBlockEntity> {
    // The skull is 9 pixels deep and modelled off-center: these move it back, away from its face.
    // Floor: centered on the block. Wall: flush with the wall behind it.
    private static final float FLOOR_Z_OFFSET = 1.93F / 16.0F;
    private static final float WALL_Z_OFFSET = -0.07F / 16.0F;

    public ImpalerHeadRenderer() {
        super(new ImpalerHeadModel());
    }

    @Override
    public ResourceLocation getTextureLocation(ImpalerHeadBlockEntity animatable) {
        return model.getTextureResource(animatable);
    }

    @Override
    public void actuallyRender(
        PoseStack poseStack,
        ImpalerHeadBlockEntity animatable,
        BakedGeoModel model,
        RenderType renderType,
        MultiBufferSource bufferSource,
        VertexConsumer buffer,
        boolean isReRender,
        float partialTick,
        int packedLight,
        int packedOverlay,
        int colour
    ) {
        if (!isReRender) {
            AnimationState<ImpalerHeadBlockEntity> animationState = 
                new AnimationState<>(animatable, 0, 0, partialTick, false);
            
            long instanceId = getInstanceId(animatable);
            GeoModel<ImpalerHeadBlockEntity> currentModel = getGeoModel();

            animationState.setData(DataTickets.TICK, animatable.getTick(animatable));
            animationState.setData(DataTickets.BLOCK_ENTITY, animatable);
            currentModel.addAdditionalStateData(animatable, instanceId, animationState::setData);

            // GeoBlockRenderer#preRender already centers the model on the block
            BlockState state = animatable.getBlockState();
            
            if (state.hasProperty(ImpalerWallHeadBlock.FACING)) {
                Direction direction = state.getValue(ImpalerWallHeadBlock.FACING);

                poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - direction.toYRot()));
                poseStack.translate(0.0F, 0.1875F, WALL_Z_OFFSET);

            } else if (state.hasProperty(ImpalerHeadBlock.ROTATION)) {
                
                int rotation = state.getValue(ImpalerHeadBlock.ROTATION);
                float degrees = RotationSegment.convertToDegrees(rotation);

                poseStack.mulPose(Axis.YP.rotationDegrees(-degrees));
                poseStack.translate(0.0F, 0.0F, FLOOR_Z_OFFSET);
            }

            currentModel.handleAnimations(animatable, instanceId, animationState, partialTick);
        }

        this.modelRenderTranslations = new Matrix4f(poseStack.last().pose());
        
        updateAnimatedTextureFrame(animatable);

        for (GeoBone group : model.topLevelBones()) {
            renderRecursively(
                poseStack, animatable, group,
                renderType, bufferSource, buffer,
                isReRender, partialTick,
                packedLight, packedOverlay,
                colour
            );
        }
    }
}
