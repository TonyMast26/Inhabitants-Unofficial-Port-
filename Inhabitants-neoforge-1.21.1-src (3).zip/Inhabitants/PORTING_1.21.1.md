# Port a NeoForge 1.21.1

Base: Inhabitants v1.2.1 per Forge 1.20.1 (commit c3461b5).

## Stato

Questo port NON e' stato compilato ne' avviato: i server di NeoForge, Mojang, Parchment,
GeckoLib e JEI non erano raggiungibili dall'ambiente in cui e' stato fatto.
Le API di NeoForge 21.1, GeckoLib 4.9.3 e JEI sono state controllate sui loro sorgenti.
Le API di Minecraft 1.21.1 no: i sorgenti non sono pubblici, quindi quelle firme vengono
dalle patch di NeoForge e dalla conoscenza della 1.21.1. Alla prima compilazione sono
quindi probabili degli errori.

## Compilare

Serve il JDK 21.

    ./gradlew build        # jar in build/libs
    ./gradlew runClient    # avvio di prova

Il workflow `.github/workflows/build.yml` compila anche su GitHub Actions.

Versioni in `gradle.properties` da verificare se Gradle non le trova:
`neo_version`, `geckolib_version`, `jei_version`, `parchment_mappings_version`.

## Cosa cambia per chi gioca

- Ricetta di brewing: oltre alla pozione normale funziona anche la conversione vanilla
  in splash e lingering con polvere da sparo e respiro del drago.
- Scuotimento dello schermo: ora ruota la camera invece di spostarla, perche' dalla
  1.20.5 il rendering del mondo non passa piu' da un PoseStack condiviso. Da regolare a
  occhio con `OFFSET_TO_DEGREES` in `CameraRenderEvent`.
- Freccia da concussione: balestra e arco usano ora il flusso vanilla tramite il tag
  `minecraft:arrows`, quindi le vecchie mixin su arco e balestra sono state rimosse.
- Incantesimi: ora sono JSON in `data/inhabitants/enchantment`. Peso, costi e tag
  (`minecraft:non_treasure`) sono stati ricalcolati per restare vicini agli originali.
- Tag `c:` al posto di `forge:` nei tag di compatibilita'.

## Da provare a mano

1. Mixin, soprattutto `SubtitleOverlayMixin`, `ImmaterialMixin`, `GiantBoneSpecialAttackMixin`
   e `ReverseGrowthMixin`: se un bersaglio non corrisponde, il log lo segnala all'avvio.
2. Shader post-processing dell'effetto Immaterial.
3. Pathfinding del Bogre (`BogrePathNavigation`).
4. Rendering in prima persona di trapano e giavellotto.
5. Mondi creati in 1.20.1: gli item salvati passano dal DataFixer di Minecraft, ma gli
   incantesimi e i dati custom della mod vanno controllati su una copia del mondo.

## Problema gia' presente nell'originale

L'advancement `david_and_goliath` usa l'icona `inhabitants:dead_bogre_icon`, ma quell'item
non e' registrato: l'advancement non viene caricato. Non e' stato modificato.

## Dopo la prima compilazione

- `CauldronMenu` estende ora `AbstractContainerMenu`: il ricettario del calderone e' tutto
  custom e non usava il `RecipeBookMenu` vanilla, che in 1.21 richiede una vera ricetta.
- Le icone del ricettario puntano ai singoli file `textures/gui/sprites/recipe_book/`.
